// Run javascript after DOM is initialized
$(document).ready(function() {

	$('#map_canvas').mapit();

});