<?php

return [
    "created" => ":type Successfully Created!",
    "updated" => ":type Successfully Updated!",
    "deleted" => ":type Successfully Deleted!",
    "saved"   => ":type Successfully Saved!",
];