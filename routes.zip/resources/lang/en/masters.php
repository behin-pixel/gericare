<?php

return [
    'sync_success' => "Sync Success !"
];