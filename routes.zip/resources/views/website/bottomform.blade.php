<section class="patron-say">
<div class="container-fluid">
<div class="row justify-content-center">

<div class="col-lg-6">
<div class="common-heading text-center">
<h2>Looking for a Consultation With Us</h2>
</div>
<div class="rechus-frms">

<form onsubmit="return valid_chk3()" name="form3" method="post" action="#" id="form3">

    
  <div class="frm-fields row clearfix">
    
    <div class="col-lg-12 col-md-12 col-sm-12 ">
    <div class="form-data cnt clearfix"><input type="text" placeholder="Name" id="aname" name="aname"></div>
    </div>
	
    <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="form-data cnt clearfix"><input type="text" placeholder="Email" id="aemail" name="aemail"></div>
    </div> 
    
    <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="form-data cnt clearfix"><input type="text" placeholder="Phone" id="aphone" name="aphone" onkeypress="return CheckNumericKeyInfo(event.keyCode, event.which)" ;="" maxlength="10"></div>
    </div>
    
    <div class="col-lg-12 col-md-12 col-sm-12 ">
    <div class="form-data cnt clearfix">
	  <select class="form-control jsrequired" id="services" name="services">
                    <option value="">Select your Service</option>
                    <option value="Doctor Visit">Geri Care Hospital</option>
										<option value="Nursing Care">Geri Care Assisted Living</option>
										<option value="Physio Care">Geri Care Consultation</option>	
										<optgroup label="Geri Homecare">
										<option value="Doctor Visit">Doctor Visit</option>
										<option value="Nursing Care">Nursing Care</option>
										<option value="Physio Care">Physio Care</option>		
										<option value="Attender Assistance">Attender Assistance</option>
										<option value="Geriatric Counselling">Geriatric Counselling</option>
										<option value="Home Blood Collection">Home Blood Collection</option>
										<option value="Lab Test">Lab Test</option>
										<option value="Vaccination">Vaccination</option>
										<option value="Dental Services">Dental Services</option>
										<option value="Medicine Delivery">Medicine Delivery</option>
										<option value="Non-Emergency Ambulance">Non-Emergency Ambulance</option>
										 </optgroup>
										</select>
	  </div>
    </div>  
	
    <div class="col-lg-12 col-md-12 col-sm-12 ">
    <div class="form-data cnt clearfix"><textarea placeholder="Your Message" name="amessage" id="amessage"></textarea></div>
    </div>
 
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
    <div class="form-data cnt clearfix"><input type="submit" name="submit" value="Submit"> </div>
    </div>
   
  </div>	

</form>

</div>
</div>

<div class="col-lg-6 dbl-reds">

<div class="common-heading text-center">
<h2>What Our Patrons Say</h2>
</div>

<div id="testimonailas" class="carousel slide text-center" data-bs-ride="carousel">

<!-- Indicators/dots -->
<div class="carousel-indicators">
  <button type="button" data-bs-target="#testimonailas" data-bs-slide-to="0" class="active"><img
      src="{{ asset('/public/website/assets/images/fem.png') }}" alt="" class="d-block"></button>
  <button type="button" data-bs-target="#testimonailas" data-bs-slide-to="1"><img
      src="{{ asset('/public/website/assets/images/mal.png') }}" alt="" class="d-block"></button>
  <button type="button" data-bs-target="#testimonailas" data-bs-slide-to="2"><img
      src="{{ asset('/public/website/assets/images/fem.png') }}" alt="" class="d-block"></button> 
</div>

<!-- The slideshow/carousel -->
<div class="carousel-inner">
  <div class="carousel-item active">
    <div class="testimonal-details">
      <p>“Gericare is the best! The care they took of my father was so good, I have switched to them for my health care also. The caregivers are truly compassionate and efficient. They keep track of all the appointments and make sure no one is kept waiting. The doctors are experienced and kind and I cannot say enough in praise of the hospital.”</p>
      <div class="testimona-nme">
        <h4>- Kalyani Komal</h4> 
      </div>
    </div>
  </div>
  <div class="carousel-item">
    <div class="testimonal-details">
      <p>“The Geri Care team has been looking after my dad with much care and proper treatment. Thank You Geri Care! The whole team is professional and prompt with their quality of service and follow ups. I was referred to this service through my neighbors who were very satisfied with the services given. This is a good option when the patient cannot be transferred easily to a hospital and back. Glad to have taken this service.”</p>
      <div class="testimona-nme">
      <h4>- AG Cecil Rozario</h4>
        <!-- <span>Retd. Professor</span> -->
      </div>
    </div>
  </div>
  <div class="carousel-item">
    <div class="testimonal-details">
      <p>“Gericare call centre staff serve with a smile. Though one cannot see the smile on the telcon, one can visualize that they serve, fix appointments, answer all the queries patiently and politely. Exceptional service, Thanks”</p>
      <div class="testimona-nme">
      <h4>- Vythialingam Iyer</h4>
        <!-- <span>Retd. Professor</span> -->
      </div>
    </div>
  </div>  
</div>

</div>

</div>

</div>
</div>
</section>